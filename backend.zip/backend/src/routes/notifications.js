'use strict';

// ─────────────────────────────────────────────
// 🔔 NOTIFICATIONS API
//    Surfaces recent activity + admin-log events as notifications.
//    The bell icon badge count comes from GET /api/notifications/count
// ─────────────────────────────────────────────

const express = require('express');
const router  = express.Router();

const db   = require('../config/database');
const wrap = require('../middleware/asyncWrapper');
const auth = require('../middleware/auth');

// ─── GET NOTIFICATION COUNT (for badge) ──────
// GET /api/notifications/count

router.get('/count', auth, wrap(async (req, res) => {
  // Count recent commits (last 7 days) the user can access
  const { rows: commitRows } = await db.query(`
    SELECT COUNT(*) AS cnt
    FROM activity a
    WHERE a.committed_at >= NOW() - INTERVAL '7 days'
      AND a.repo_id IN (
        SELECT repo_id FROM permissions
        WHERE
          (subject_type = 'user'  AND subject_id = $1)
          OR
          (subject_type = 'group' AND subject_id IN (
            SELECT group_id FROM group_members WHERE user_id = $1
          ))
      )
  `, [req.user.id]);

  // Admins/super_admins also see admin log events
  let adminCount = 0;
  if (['admin', 'super_admin'].includes(req.user.role)) {
    const { rows: adminRows } = await db.query(`
      SELECT COUNT(*) AS cnt
      FROM admin_logs
      WHERE created_at >= NOW() - INTERVAL '7 days'
    `);
    adminCount = parseInt(adminRows[0].cnt, 10);
  }

  const total = parseInt(commitRows[0].cnt, 10) + adminCount;

  res.json({ count: Math.min(total, 99) }); // cap at 99 for badge display
}));

// ─── GET NOTIFICATIONS LIST ───────────────────
// GET /api/notifications?limit=20&offset=0

router.get('/', auth, wrap(async (req, res) => {
  const limit  = Math.min(parseInt(req.query.limit)  || 20, 50);
  const offset = Math.max(parseInt(req.query.offset) || 0,  0);

  // Recent commits the user can see
  const { rows: commits } = await db.query(`
    SELECT
      'commit'           AS type,
      a.id,
      a.author           AS actor,
      a.message          AS description,
      r.name             AS context,
      a.committed_at     AS created_at,
      a.revision
    FROM activity a
    JOIN repositories r ON r.id = a.repo_id
    WHERE a.repo_id IN (
      SELECT repo_id FROM permissions
      WHERE
        (subject_type = 'user'  AND subject_id = $1)
        OR
        (subject_type = 'group' AND subject_id IN (
          SELECT group_id FROM group_members WHERE user_id = $1
        ))
    )
    ORDER BY a.committed_at DESC
    LIMIT $2
  `, [req.user.id, limit]);

  // Admin events (only for admins)
  let adminEvents = [];
  if (['admin', 'super_admin'].includes(req.user.role)) {
    const { rows } = await db.query(`
      SELECT
        'admin'      AS type,
        al.id,
        u.username   AS actor,
        al.action    AS description,
        al.entity    AS context,
        al.created_at,
        NULL         AS revision
      FROM admin_logs al
      LEFT JOIN users u ON u.id = al.user_id
      ORDER BY al.created_at DESC
      LIMIT $1
    `, [limit]);
    adminEvents = rows;
  }

  // Merge and sort by created_at desc, then paginate
  const all = [...commits, ...adminEvents]
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
    .slice(offset, offset + limit);

  res.json({
    total: all.length,
    limit,
    offset,
    data:  all,
  });
}));

// ─── MARK ALL READ (no-op for now — no read-state column) ────
// POST /api/notifications/mark-read

router.post('/mark-read', auth, wrap(async (_req, res) => {
  // Future: add a user_notification_reads table
  res.json({ message: 'Marked as read' });
}));

module.exports = router;