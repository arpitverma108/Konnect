'use strict';

const express  = require('express');
const Joi      = require('joi');
const router   = express.Router();

const db       = require('../config/database');
const validate = require('../middleware/validate');
const wrap     = require('../middleware/asyncWrapper');
const auth     = require('../middleware/auth');
const authorize = require('../middleware/authorize');
const checkPermission = require('../middleware/checkPermission');
const authzSvc = require('../services/authzService');


// ─── Validation ─────────────────────────────

const createGroupSchema = Joi.object({
  name: Joi.string().pattern(/^[a-zA-Z0-9._-]+$/).min(1).max(64).required(),
  description: Joi.string().max(512).optional().allow('', null),
});

const addMemberSchema = Joi.object({
  userId: Joi.number().integer().required(),
});


// ─── GET ALL GROUPS (ALL USERS) ─────────────

router.get('/', auth, wrap(async (req, res) => {
  const { rows } = await db.query(`
    SELECT g.*,
    COUNT(gm.user_id) AS member_count
    FROM groups g
    LEFT JOIN group_members gm ON gm.group_id = g.id
    GROUP BY g.id
    ORDER BY g.name
  `);

  res.json(rows);
}));


// ─── CREATE GROUP (ADMIN) ─────────────

router.post(
  '/',
  auth,
  authorize("admin", "super_admin"),
  validate(createGroupSchema),
  wrap(async (req, res) => {

    const { name, description } = req.body;

    const { rows } = await db.query(
      `INSERT INTO groups (name, description)
       VALUES ($1, $2)
       RETURNING *`,
      [name, description || null]
    );

    await authzSvc.rebuildAuthzFile(db);

    res.status(201).json(rows[0]);
  })
);


// ─── GET SINGLE GROUP (ALL USERS) ─────────────

router.get('/:id', auth, wrap(async (req, res) => {

  const { rows } = await db.query(
    'SELECT * FROM groups WHERE id = $1',
    [req.params.id]
  );

  if (!rows.length) {
    return res.status(404).json({ error: 'Group not found' });
  }

  res.json(rows[0]);
}));


// ─── DELETE GROUP (SUPER ADMIN ONLY) ─────────────

router.delete(
  '/:id',
  auth,
  authorize("super_admin"),
  wrap(async (req, res) => {

    const { rows } = await db.query(
      'DELETE FROM groups WHERE id = $1 RETURNING name',
      [req.params.id]
    );

    if (!rows[0]) {
      return res.status(404).json({ error: 'Group not found' });
    }

    await authzSvc.rebuildAuthzFile(db);

    res.json({ message: `Group '${rows[0].name}' deleted` });
  })
);


// ─── GET MEMBERS (ALL USERS) ─────────────

router.get('/:id/members', auth, wrap(async (req, res) => {

  const { rows } = await db.query(`
    SELECT u.id, u.username, u.email, u.full_name
    FROM group_members gm
    JOIN users u ON u.id = gm.user_id
    WHERE gm.group_id = $1
    ORDER BY u.username
  `, [req.params.id]);

  res.json(rows);
}));


// ─── ADD MEMBER (ADMIN) ─────────────

router.post(
  '/:id/members',
  auth,
  authorize("admin", "super_admin"),
  validate(addMemberSchema),
  wrap(async (req, res) => {

    const { userId } = req.body;

    await db.query(
      `INSERT INTO group_members (group_id, user_id)
       VALUES ($1, $2)
       ON CONFLICT DO NOTHING`,
      [req.params.id, userId]
    );

    await authzSvc.rebuildAuthzFile(db);

    res.status(201).json({ message: 'Member added' });
  })
);


// ─── REMOVE MEMBER (ADMIN) ─────────────

router.delete(
  '/:id/members/:userId',
  auth,
  authorize("admin", "super_admin"),
  wrap(async (req, res) => {

    await db.query(
      'DELETE FROM group_members WHERE group_id = $1 AND user_id = $2',
      [req.params.id, req.params.userId]
    );

    await authzSvc.rebuildAuthzFile(db);

    res.json({ message: 'Member removed' });
  })
);


// ─── EXPORT ─────────────
module.exports = router;